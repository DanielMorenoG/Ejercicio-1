const fs = require('fs');
const path = require('path');

const folderName = 'miCarpeta';
const repoFile = 'repositorio.txt';
const folderPath = path.join(__dirname, folderName);
const filePath = path.join(folderPath, repoFile);


if (!fs.existsSync(folderPath)) {

    fs.mkdirSync(folderPath);
    fs.writeFileSync(filePath, 'huevon', 'utf8');
    console.log('Carpeta y archivo creados con contenido.');
} else {
    
    if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
    }
    fs.rmdirSync(folderPath);
    console.log('Archivo y carpeta eliminados. Todo limpio.');
}
