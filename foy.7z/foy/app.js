/*const http=requiere('http')

var options={
    hostname:'localhost',
    portal:80,
    path:'/dashboard/phpinfo.php',
    method:'GET'
}
var req=http.request(options,res=>{
    console.log(`status code:${res.statusCode}`)
    console.log(`Data:%j`,res.headers)
    let f=''
    res.on('data',gol=>{
        f+gol
    })
    res.on('end',()=>{
        console.log('\n\nResultados:')
        console.log(f)
    })
})
req.on(`error`,err=>{})
req.end()
*/
var http=require('http')
var fs=require('fs')
var parth=require('path')

http.createServer((req,res)=>{
console.log(`${req.method} Solicita ${req.url}`)
//html
if(req.url=='/'){
    fs.readFile('./Paginaa/index.html','utf-8',(err,html)=>{
        res.writeHead(200,{'Content-Type':'text/html'})
        res.end(html)
    })
}
//css
else if(req.url.match(/.css$/)){
 var estilo=parth.join(__dirname,'Paginaa',req.url)
 var file=fs.createReadStream(estilo,'utf-8')
res.writeHead(200,{'Content-Type':'text/css'})
file.pipe(res)
}
//img
else if(req.url.match(/.png$/)){
 var estilo=parth.join(__dirname,'Paginaa',req.url)
 var file=fs.createReadStream(estilo,'utf-8')
res.writeHead(200,{'Content-Type':'image.png'})
file.pipe(res)}

//
else{
res.writeHead(400,{'Content-Type':'text/html'})
res.end('400 error')
}
   
}).listen(5000)
console.log('Iniciando')
localhost:5000