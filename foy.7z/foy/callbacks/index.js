const XMLHttpRequest = require('xmlhttprequest').XMLHttpRequest;

// 1. Obtener datos completos del Pokémon
function getPokemon(pokemonName, callback) {
  const apiUrl = `https://pokeapi.co/api/v2/pokemon/${pokemonName}`;
  const xhr = new XMLHttpRequest();
  xhr.open("GET", apiUrl, true);
  xhr.onload = function() {
    if (xhr.status === 200) {
      const data = JSON.parse(xhr.responseText);
      callback(null, data);
    } else {
      const error = new Error(`Error: ${xhr.status}`);
      callback(error, null);
    }
  };
  xhr.onerror = function() {
    const error = new Error("Network Error");
    callback(error, null);
  };
  xhr.send();
}

// 2. Obtener peso del Pokémon
function getPokemonWeight(pokemonName, callback) {
  const apiUrl = `https://pokeapi.co/api/v2/pokemon/${pokemonName}`;
  const xhr = new XMLHttpRequest();
  xhr.open("GET", apiUrl, true);
  xhr.onload = function() {
    if (xhr.status === 200) {
      const data = JSON.parse(xhr.responseText);
      callback(null, data.weight);
    } else {
      const error = new Error(`Error: ${xhr.status}`);
      callback(error, null);
    }
  };
  xhr.onerror = function() {
    const error = new Error("Network Error");
    callback(error, null);
  };
  xhr.send();
}

// 3. Obtener todas las habilidades del Pokémon
function getPokemonAbilities(pokemonName, callback) {
  const apiUrl = `https://pokeapi.co/api/v2/pokemon/${pokemonName}`;
  const xhr = new XMLHttpRequest();
  xhr.open("GET", apiUrl, true);
  xhr.onload = function() {
    if (xhr.status === 200) {
      const data = JSON.parse(xhr.responseText);
      const abilities = data.abilities.map(item => item.ability.name);
      callback(null, abilities);
    } else {
      const error = new Error(`Error: ${xhr.status}`);
      callback(error, null);
    }
  };
  xhr.onerror = function() {
    const error = new Error("Network Error");
    callback(error, null);
  };
  xhr.send();
}

// Ejemplo de uso encadenado:
getPokemon('pikachu', (err, pokemonData) => {
  if (err) {
    console.error(err.message);
    return;
  }
  console.log('Nombre:', pokemonData.name);

  getPokemonWeight('pikachu', (err, weight) => {
    if (err) {
      console.error(err.message);
      return;
    }
    console.log('Peso:', weight);

    getPokemonAbilities('pikachu', (err, abilities) => {
      if (err) {
        console.error(err.message);
        return;
      }
      console.log('Habilidades:', abilities);
      if (abilities.length >= 2) {
        console.log('Segunda habilidad:', abilities[1]);
      } else {
        console.log('Este Pokémon no tiene una segunda habilidad.');
      }
    });
  });
});
